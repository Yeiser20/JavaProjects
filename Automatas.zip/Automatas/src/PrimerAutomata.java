
import java.lang.invoke.StringConcatFactory;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class PrimerAutomata {

	static int cn = 0;
	char cad = 0;
	static String cadena = "";

	public static void main(String[] args) {
		Estados e = new Estados();	
		 e.iniciar();
	}
}
	

